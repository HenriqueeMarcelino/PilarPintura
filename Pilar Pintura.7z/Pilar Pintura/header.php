<header class="d-flex justify-content-center py-3">
  <h1>Pilar Pinturas</h1>
  <ul class="nav nav-pills">
  </ul>
</header>
  <header class="d-flex justify-content-center py-3">
    <ul class="nav nav-pills">
     <a href="index.php" class="nav-link">Home</a>
     <a href="portfolio.php" class="nav-link">Portfolio</a>
     <a href="sobre.php" class="nav-link">Sobre</a>
    <a href="contato.php" class="nav-link">Contato</a>
</ul>
  </header>,

  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css">
<a href="https://wa.me/55(aqui seu numero com ddd | tudo junto)?text=Adorei%20seu%20artigo" style="position:fixed;width:60px;height:60px;bottom:40px;right:40px;background-color:#25d366;color:#FFF;border-radius:50px;text-align:center;font-size:30px;box-shadow: 1px 1px 2px #888;
  z-index:1000;" target="_blank">
<i style="margin-top:16px" class="fa fa-whatsapp"></i>
</a>